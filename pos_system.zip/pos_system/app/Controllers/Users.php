<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index()
    {
        $users = [
            [
                'username' => 'admin01',
                'full_name' => 'Aneryl Alafriz',
                'role' => 'Administrator'
            ],
            [
                'username' => 'cashier01',
                'full_name' => 'Mark Santos',
                'role' => 'Cashier'
            ],
            [
                'username' => 'cashier02',
                'full_name' => 'Liza Soberano',
                'role' => 'Cashier'
            ],
            [
                'username' => 'manager01',
                'full_name' => 'Daniel Padilla',
                'role' => 'Manager'
            ],
            [
                'username' => 'staff01',
                'full_name' => 'Sofia The First',
                'role' => 'Staff'
            ]
        ];

        return view('users/index', [
            'users' => $users
        ]);
    }
}