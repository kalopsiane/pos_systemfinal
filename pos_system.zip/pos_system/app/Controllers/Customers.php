<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index()
    {
        $customers = [
            [
                'full_name' => 'Aneryl Alafriz',
                'email' => 'amalafriz@example.com',
                'phone' => '09171234567'
            ],
            [
                'full_name' => 'Desiree Bondoc',
                'email' => 'dsbondoc@example.com',
                'phone' => '09181234567'
            ],
            [
                'full_name' => 'Anjelene Casimiro',
                'email' => 'accasimiro@example.com',
                'phone' => '09191234567'
            ],
            [
                'full_name' => 'Beatrice Shenel Alafriz',
                'email' => 'bsalafriz@example.com',
                'phone' => '09201234567'
            ],
            [
                'full_name' => 'Rene Baterbonia',
                'email' => 'rbaterbonia@example.com',
                'phone' => '09211234567'
            ]
        ];

        return view('customers/index', [
            'customers' => $customers
        ]);
    }
}