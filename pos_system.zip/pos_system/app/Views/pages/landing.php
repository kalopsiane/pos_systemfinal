<!DOCTYPE html>
<html>
<head>
    <title>POS System</title>
</head>
<body>
    <h1>Point-of-Sale System</h1>
    <p>Welcome to the POS system.</p>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a> |
        <a href="<?= base_url('about') ?>">About</a> |
        <a href="<?= base_url('customers') ?>">Customer Accounts</a> |
        <a href="<?= base_url('users') ?>">User Accounts</a>
    </nav>
</body>
</html>