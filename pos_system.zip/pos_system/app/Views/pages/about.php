<!DOCTYPE html>
<html>
<head>
    <title>About - POS System</title>
</head>
<body>
    <h1>About the POS System</h1>
    <p>This system manages customer and staff account information.</p>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a> |
        <a href="<?= base_url('about') ?>">About</a> |
        <a href="<?= base_url('customers') ?>">Customer Accounts</a> |
        <a href="<?= base_url('users') ?>">User Accounts</a>
    </nav>
</body>
</html>